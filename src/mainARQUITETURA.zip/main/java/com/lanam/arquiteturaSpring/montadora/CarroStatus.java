package com.lanam.arquiteturaSpring.montadora;

public record CarroStatus(String mensagem) {

}
