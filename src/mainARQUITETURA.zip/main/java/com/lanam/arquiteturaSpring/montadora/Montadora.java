package com.lanam.arquiteturaSpring.montadora;

public enum Montadora {
    HONDA,
    TOYOTA
}
