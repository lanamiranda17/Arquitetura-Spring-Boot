package com.lanam.arquiteturaSpring.montadora;

public enum TipoMotor {
    ASPIRADO,
    TURBO,
    ELETRICO
}

